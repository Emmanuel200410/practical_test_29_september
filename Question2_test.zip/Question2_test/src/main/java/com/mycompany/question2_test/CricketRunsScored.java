/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question2_test;

/**
 *
 * @author RC_Student_lab
 */
public class CricketRunsScored extends Cricket{
    
   public  CricketRunsScored(String name, String stadium_name,int Runs){
      
super(name,stadium_name,Runs);
    
    
   } 
    
  public void Printreport(){
      System.out.println(" batsmans name " + name +" stadium name " + stadium_name + " total runs " + Runs );   
    
    
    
    
    
    
    
    
  
  }  
    
    
}
