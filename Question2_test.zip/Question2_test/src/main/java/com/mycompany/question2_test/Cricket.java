/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question2_test;

/**
 *
 * @author RC_Student_lab
 */
abstract class Cricket implements ICricket {
    
 String name;    
  String stadium_name;
  int Runs;
  
  
 public  Cricket(String  name,String stadium_name,
 int Runs){
     this.name = name;
     this. stadium_name = stadium_name;
     this.  Runs =  Runs;
 }
 
 
 
@Override
    public String getName() {
        return name;
    }
@Override
    public String getStadium_name() {
        return stadium_name;
    }
@Override
    public int getRuns() {
        return Runs;
    }
 }

