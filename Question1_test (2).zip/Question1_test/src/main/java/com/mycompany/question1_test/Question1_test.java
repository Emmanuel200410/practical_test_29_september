/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question1_test;

/**
 *
 * @author RC_Student_lab
 */
public class Question1_test {

    public static void main(String[] args) {
        System.out.println("Hello World!");

        String[] jobs = {"jacques kalis", "hashim amala", "ab de villers"};
        String[] stadiums = {"Kingsmead", "st George", "Wanderes"};

        // Sales data [jobs][months]
        int[][] runs  = {
            {5000,3500,6200},   
            {3800,3700,5000},   
            {4200,3900,5200}    
        };

        System.out.println("laptop SALES REPORT - 2025\n");

        // Print header row (jobs on top)
        System.out.printf("%-10s", ""); 
        for (String job : jobs) {
            System.out.printf("%10s", job);
        }
        System.out.printf("%10s\n", "TOTAL");
        System.out.println("--------------------------------------------------");

        // Print month rows
        for (int j = 0; j < stadiums.length; j++) {
            int rowTotal = 0;
            System.out.printf("%-10s", stadiums[j]);

            for (int i = 0; i < jobs.length; i++) {
                System.out.printf("%10d", runs [i][j]);
                rowTotal +=  runs [i][j];
            }

            System.out.printf("%10d\n", rowTotal);
        }

        // Print totals row (grand totals per job + overall)
        System.out.println("--------------------------------------------------");
        System.out.printf("%-10s", "TOTAL");

        int grandTotal = 0;
        for (int i = 0; i < jobs.length; i++) {
            int colTotal = 0;
            for (int j = 0; j < stadiums.length; j++) {
                colTotal +=  runs [i][j];
            }
            System.out.printf("%10d", colTotal);
            grandTotal += colTotal;
        }
        System.out.printf("%10d\n", grandTotal);
    }
}