/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question2_test;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class Question2_test {

    public static void main(String[] args) {
      
          Scanner sc = new Scanner(System.in);

        // Input from user
        System.out.print("Enter  batsmans name: ");
        String name = sc.nextLine();

        System.out.print("Enter stadium name: ");
        String stadium_name = sc.nextLine();

          System.out.print("Enter total runs: ");
       int Runs = sc.nextInt();


            CricketRunsScored obj = new   CricketRunsScored(name, stadium_name,Runs );
            obj.Printreport();
    }
}
